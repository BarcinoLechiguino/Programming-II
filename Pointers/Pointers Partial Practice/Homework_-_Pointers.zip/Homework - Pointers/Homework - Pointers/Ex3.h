#pragma once

void ex3();
