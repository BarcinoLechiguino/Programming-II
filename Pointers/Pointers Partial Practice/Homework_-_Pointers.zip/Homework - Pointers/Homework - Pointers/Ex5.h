#pragma once

void ex5();
