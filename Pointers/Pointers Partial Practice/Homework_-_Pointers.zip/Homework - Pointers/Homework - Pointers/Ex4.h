#pragma once

void ex4();
