#pragma once

void ex2();
