#pragma once

void ex1();