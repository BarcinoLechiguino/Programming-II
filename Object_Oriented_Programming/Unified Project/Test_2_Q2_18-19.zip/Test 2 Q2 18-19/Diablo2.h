/* ----------------------------------------------------------------------- */
/*                          TYPE YOUR NAME HERE                            */
/* ----------------------------------------------------------------------- */

#ifndef DIABLO2_H
#define DIABLO2_H

//////////////CHARACTER
class Character
{
};



//////////////BARBARIAN



//////////////PALADIN



//////////////WIZARD



//////////////EVALUATE ATTACK
void evaluateAttack(Character* attacker, Character* defender)
{
}

#endif