/* ----------------------------------------------------------------------- */
/*                         INSERT YOUR NAME HERE                           */
/* ----------------------------------------------------------------------- */

#ifndef EX2_H
#define EX2_H

// Uncomment to test the exercise
//#define TEST_EX2

int partialSum(int* pIntArray, int pArraySize, int pInitPos, int pEndPos)
{


	// TO DO: Insert your code here

	return 0;
}


#endif