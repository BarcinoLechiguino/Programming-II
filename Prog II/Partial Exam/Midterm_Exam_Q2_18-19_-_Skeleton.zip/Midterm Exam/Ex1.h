/* ----------------------------------------------------------------------- */
/*                         INSERT YOUR NAME HERE                           */
/* ----------------------------------------------------------------------- */

#ifndef EX1_H
#define EX1_H

// Uncomment to test the exercise
//#define TEST_EX1

/** Maximum number of items in the inventory. */
static const int MAX_ITEMS = 9;

/** Enumerated type for items. */
enum class Item {
	Food,
	Sword,
	Torch,
	Empty
};



// TO DO: Insert your code here




#endif
