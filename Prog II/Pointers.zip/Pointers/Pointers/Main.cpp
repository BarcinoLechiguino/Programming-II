#include <stdio.h>
#include <stdlib.h>
#include <iostream>

void clear(int *x)
{
	*x = 0;
}

void practice()
{
	int energy = 100;
	int *ptr = &energy;
	*ptr = 50;
	std::cout << energy << std::endl;
	//printf("%d", energy);

	int val = 10;
	std::cout << "Before clear: " << val << std::endl;
	clear(&val);
	std::cout << "After clear: " << val << std::endl;

	int bar = 3;
	int *foo = &bar;
	int *baz = foo; //Pointer to the address where the previous pointer "foo" was pointing at.
	int **zap = &foo; //Pointer to another pointer's address in memory.
	std::cout << bar << std::endl;
	std::cout << zap << std::endl;
}

void ExerciseI()
{
	int num = 3;
	std::cout << "Memory address of num: "<< &num << std::endl;
	int *ptr = &num;
	std::cout << "Memory address where the pointer points: " << ptr << std::endl;
	std::cout << "Variable stored in the memory address: " << *ptr << std::endl;
	*ptr = 20;
	std::cout << "Changed value of num: " << *ptr << std::endl;
}

void pointerArrays()
{
	int vec[10] = {};
	int *ptr = &vec[2]; //We use the & as to give the pointer the memory address. Without it it would give an integer to the pointer causing a crash.
}

void ExerciseII()
{
	int vec[3] = { 1, 2, 3 };
	
	for (int i = 0; i < 3; i++)
	{
		int *ptr = &vec[i];
		std::cout << "Memory address of the first element in the array: " << ptr << std::endl;
		std::cout << "Variable stored in the first element of the array: " << *ptr << std::endl;
	}
}

int main()
{
	practice();
	printf("\n");
	ExerciseI();
	pointerArrays();
	printf("\n");
	ExerciseII();

	system("pause");
	return 0;
}