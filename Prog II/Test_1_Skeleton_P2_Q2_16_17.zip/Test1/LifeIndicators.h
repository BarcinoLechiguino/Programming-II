/* ----------------------------------------------------------------------- */
/*                         INSERT YOUR NAME HERE                           */
/* ----------------------------------------------------------------------- */

#ifndef LIFEINDICATORS_H
#define LIFEINDICATORS_H

#include <iostream>

typedef unsigned short ushort;


void updateLifeIndicatorPlayer1(ushort* lifeIndicatorP1, ushort damage)
{
	
	// TO DO: Insert your code here
	
}


void updateLifeIndicatorPlayer2(ushort* lifeIndicatorP2, ushort damage)
{
	
	// TO DO: Insert your code here

}

#endif