#include <stdio.h>
#include <stdlib.h>
#include <iostream>

//void ExerciseI()
//{
//	int energy = 100;
//	int *ptr = &energy;
//	*ptr = 50;
//
//	std::cout << ptr << std::endl; //Address in memory.
//	std::cout << *ptr << std::endl; //Variable in the memory address.
//}
//
//int main()
//{
//	ExerciseI();
//
//	system("pause");
//	return 0;
//}